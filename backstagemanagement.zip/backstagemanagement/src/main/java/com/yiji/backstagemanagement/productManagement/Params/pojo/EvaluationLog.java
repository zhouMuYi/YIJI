package com.yiji.backstagemanagement.productManagement.Params.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * 估价日志
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EvaluationLog {
    private int logId;              //日志ID
    private String changeAccount;   //变更人
    private int fromState;          //变更前状态
    private int toState;            //变更后状态
    private Date changeTime;        //变更时间
}
