package com.yiji.backstagemanagement.authManagement;

/**
 * 这个类，没有用处，只是用来便于分包
 */
public class Sys {
}
