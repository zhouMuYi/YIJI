package com.yiji.backstagemanagement.productManagement.Params.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * 估价参数大项
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EvaluationParamtersMajor {
    private int majorId;        //大项参数ID
    private String majorName;   //参数名称
    private int brandId;       //所属品牌ID
    private int modelId;       //所属机型ID
    private int state;          //状态
    private Date createTime;    //创建时间
}
