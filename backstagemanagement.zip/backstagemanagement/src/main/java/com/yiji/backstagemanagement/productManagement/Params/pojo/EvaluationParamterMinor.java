package com.yiji.backstagemanagement.productManagement.Params.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * 估价参数小项
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EvaluationParamterMinor {
    private int minorId;        //小项参数ID
    private String minorName;   //小项参数名称
    private int parentId;       //父项ID
    private double money;       //对应金额
    private int state;          //状态
    private Date createTime;    //创建时间
}
