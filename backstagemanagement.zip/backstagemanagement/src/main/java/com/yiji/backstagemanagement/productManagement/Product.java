package com.yiji.backstagemanagement.productManagement;

public class Product {
}
