package com.yiji.backstagemanagement.productManagement.Params.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * 估价计算公式
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EvaluationCalculationFormula {
    private int formulaId;      //公式ID
    private String model;       //适用机型
    private String algorithm;   //算法
    private int state;          //状态
    private Date createTime;    //创建时间
}
